package interpreter;

import org.antlr.v4.runtime.ParserRuleContext;
import java.util.*;

/**
 * Stores the static metadata for a Delphi class definition.
 * This includes: parent class name, field declarations (name→type),
 * method bodies (name→parse-tree node), and visibility information.
 */
public class ClassDefinition {

    public final String name;
    public final String parentClassName;   // null if no explicit parent

    /** Field name → declared type string */
    public final Map<String, String> fields = new LinkedHashMap<>();

    /** Visibility of each field or method (name → "private" / "protected" / "public") */
    public final Map<String, String> visibility = new LinkedHashMap<>();

    /** Method name (lower-case) → parse-tree context for CONSTRUCTOR */
    public final Map<String, ParserRuleContext> constructors = new LinkedHashMap<>();

    /** Method name (lower-case) → parse-tree context for DESTRUCTOR */
    public final Map<String, ParserRuleContext> destructors = new LinkedHashMap<>();

    /** Method name (lower-case) → parse-tree context for PROCEDURE / FUNCTION */
    public final Map<String, ParserRuleContext> methods = new LinkedHashMap<>();

    /** Whether the method is declared virtual/override in the class header */
    public final Set<String> virtualMethods = new HashSet<>();

    /** Interface names this class claims to implement (not enforced at runtime, demo only) */
    public final List<String> implementedInterfaces = new ArrayList<>();

    public ClassDefinition(String name, String parentClassName) {
        this.name = name;
        this.parentClassName = parentClassName;
    }

    /** Look up a method walking up the inheritance chain via the registry. */
    public ParserRuleContext lookupMethod(String methodName,
                                          Map<String, ClassDefinition> classRegistry) {
        String key = methodName.toLowerCase();
        if (methods.containsKey(key)) return methods.get(key);
        if (constructors.containsKey(key)) return constructors.get(key);
        if (destructors.containsKey(key)) return destructors.get(key);

        // walk up inheritance chain
        if (parentClassName != null) {
            ClassDefinition parent = classRegistry.get(parentClassName.toLowerCase());
            if (parent != null) return parent.lookupMethod(methodName, classRegistry);
        }
        return null;
    }

    /** Return all field names, including inherited ones (closest first). */
    public Map<String, String> allFields(Map<String, ClassDefinition> classRegistry) {
        Map<String, String> result = new LinkedHashMap<>();
        if (parentClassName != null) {
            ClassDefinition parent = classRegistry.get(parentClassName.toLowerCase());
            if (parent != null) result.putAll(parent.allFields(classRegistry));
        }
        result.putAll(fields);   // child fields shadow parent
        return result;
    }

    @Override
    public String toString() {
        return "ClassDef(" + name +
                (parentClassName != null ? " extends " + parentClassName : "") + ")";
    }
}
