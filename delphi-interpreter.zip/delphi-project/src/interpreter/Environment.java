package interpreter;

import java.util.*;

/**
 * Lexical-scope environment (linked list of symbol tables).
 * Supports get / set / define with proper scope walking.
 */
public class Environment {

    private final Map<String, Object> vars = new LinkedHashMap<>();
    private final Environment parent;

    public Environment(Environment parent) {
        this.parent = parent;
    }

    /** Define a NEW variable in THIS scope (may shadow outer). */
    public void define(String name, Object value) {
        vars.put(name.toLowerCase(), value);
    }

    /** Read a variable, walking up to parent scopes. */
    public Object get(String name) {
        String key = name.toLowerCase();
        if (vars.containsKey(key)) return vars.get(key);
        if (parent != null) return parent.get(name);
        throw new RuntimeException("Undefined variable: " + name);
    }

    /** Check existence without throwing. */
    public boolean has(String name) {
        String key = name.toLowerCase();
        if (vars.containsKey(key)) return true;
        if (parent != null) return parent.has(name);
        return false;
    }

    /** Update an existing variable (walks to the scope that owns it). */
    public void set(String name, Object value) {
        String key = name.toLowerCase();
        if (vars.containsKey(key)) {
            vars.put(key, value);
        } else if (parent != null) {
            parent.set(name, value);
        } else {
            // auto-define at top level to be lenient
            vars.put(key, value);
        }
    }

    public Environment getParent() { return parent; }

    @Override
    public String toString() {
        return vars.toString() + (parent != null ? " -> " + parent : "");
    }
}
