package interpreter;

/** Thrown to implement FUNCTION return (carries the return value). */
public class ReturnException extends RuntimeException {
    public final Object value;
    public ReturnException(Object value) {
        super(null, null, true, false);
        this.value = value;
    }
}
