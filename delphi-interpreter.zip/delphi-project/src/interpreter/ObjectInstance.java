package interpreter;

import java.util.*;

/**
 * A runtime instance of a Delphi class.
 * Stores the actual field values and knows its class definition.
 */
public class ObjectInstance {

    public final ClassDefinition classDef;

    /** Field storage: field name (lower-case) → value */
    private final Map<String, Object> fields = new LinkedHashMap<>();

    public ObjectInstance(ClassDefinition classDef, Map<String, ClassDefinition> registry) {
        this.classDef = classDef;
        // pre-initialise every field to a default value
        for (Map.Entry<String, String> e : classDef.allFields(registry).entrySet()) {
            fields.put(e.getKey().toLowerCase(), defaultValue(e.getValue()));
        }
    }

    private Object defaultValue(String type) {
        if (type == null) return null;
        switch (type.toLowerCase()) {
            case "integer": return 0;
            case "real":    return 0.0;
            case "boolean": return false;
            case "char":    return '\0';
            case "string":  return "";
            default:        return null;   // object reference: nil
        }
    }

    public Object getField(String name) {
        return fields.get(name.toLowerCase());
    }

    public void setField(String name, Object value) {
        fields.put(name.toLowerCase(), value);
    }

    public boolean hasField(String name) {
        return fields.containsKey(name.toLowerCase());
    }

    /** For printing / debugging */
    @Override
    public String toString() {
        return classDef.name + "@" + System.identityHashCode(this) + fields;
    }
}
