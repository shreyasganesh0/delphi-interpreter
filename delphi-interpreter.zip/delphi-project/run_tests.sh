#!/bin/bash
# ============================================================
#  run_tests.sh  –  Run all .pas test files through the interpreter
# ============================================================

ANTLR_JAR="antlr-4.13.2-complete.jar"
BIN_DIR="bin"
TEST_DIR="tests"
PASS=0
FAIL=0

if [ ! -d "$BIN_DIR" ]; then
  echo "ERROR: bin/ not found. Run ./build.sh first."
  exit 1
fi

# ── Helper: run one test ──────────────────────────────────────
run_test() {
  local file="$1"
  local name=$(basename "$file")
  local input_file="${file%.pas}.input"

  echo "──────────────────────────────────────────────────────"
  echo "TEST: $name"
  echo "──────────────────────────────────────────────────────"

  if [ -f "$input_file" ]; then
    # Supply pre-canned stdin for tests that use ReadLn
    output=$(java -cp "$BIN_DIR:$ANTLR_JAR" interpreter.DelphiInterpreter "$file" \
                  < "$input_file" 2>&1)
  else
    # Provide a default integer so ReadLn never hangs
    output=$(echo "42" | java -cp "$BIN_DIR:$ANTLR_JAR" interpreter.DelphiInterpreter "$file" 2>&1)
  fi

  echo "$output"

  if echo "$output" | grep -qi "\[parse error\]\|\[runtime error\]\|exception"; then
    echo ">>> RESULT: FAIL ✗"
    FAIL=$((FAIL + 1))
  else
    echo ">>> RESULT: PASS ✓"
    PASS=$((PASS + 1))
  fi
  echo
}

# ── Run all tests ─────────────────────────────────────────────
for f in "$TEST_DIR"/test*.pas; do
  run_test "$f"
done

echo "======================================================"
echo " SUMMARY:  $PASS passed,  $FAIL failed"
echo "======================================================"
